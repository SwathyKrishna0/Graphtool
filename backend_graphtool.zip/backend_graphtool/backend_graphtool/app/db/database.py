from firebase_admin import db
 
def get_db():
    """Returns the Firebase database reference."""
    return db.reference()
 
def save_data(graph_data):
    """Stores processed graph data in Firebase."""
    db_ref = get_db().child("graph_data")
    db_ref.set(graph_data)
 
def fetch_data():
    """Retrieves stored graph data from Firebase."""
    db_ref = get_db().child("graph_data")
    return db_ref.get()
 