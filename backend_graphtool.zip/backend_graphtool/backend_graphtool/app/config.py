import os
 
class Config:
    """Project-wide configuration settings."""
 
    # Firebase Configuration
    FIREBASE_CREDENTIALS = os.getenv("FIREBASE_CREDENTIALS", "firebase_credentials.json")
    FIREBASE_COLLECTION = os.getenv("FIREBASE_COLLECTION", "graphs")
    FIREBASE_DOCUMENT = os.getenv("FIREBASE_DOCUMENT", "grid_data")
 
    # Matplotlib Default Settings
    MATPLOTLIB_STYLE = os.getenv("MATPLOTLIB_STYLE", "seaborn-darkgrid")
    DEFAULT_PLOT_TYPE = os.getenv("DEFAULT_PLOT_TYPE", "imshow")
 
    # API Settings
    API_TITLE = "FastAPI Graph Generator"
    API_VERSION = "1.0.0"
 
# Initialize configuration instance
config = Config()