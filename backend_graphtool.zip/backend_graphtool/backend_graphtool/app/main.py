from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import graph
from app.routes import data 
 
app = FastAPI()

# Include modular routes
app.include_router(data.router, prefix="/api")

##Enable CORS to allow frontend communication\
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
 
app.include_router(graph.router)
 
@app.get("/")
def home():
    return {"message": "Welcome to FastAPI Graph Generator"}
    