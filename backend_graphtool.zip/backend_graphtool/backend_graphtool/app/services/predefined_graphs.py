import matplotlib.pyplot as plt
import numpy as np
import io
import base64
from fastapi import Response

def generate_plot(plot_type: str, values: dict = None):
    fig, ax = plt.subplots()
 
    if plot_type == "line":
        ax.plot(values.get("x", []), values.get("y", []))
    elif plot_type == "bar":
        ax.bar(values.get("labels", []), values.get("heights", []))
    elif plot_type == "histogram":
        ax.hist(values.get("data", []), bins=values.get("bins", 10))
    elif plot_type == "box":
        ax.boxplot(values.get("data", []))
    elif plot_type == "heatmap":
        data = np.array(values.get("matrix", np.random.rand(10, 10)))
        ax.imshow(data, cmap=values.get("cmap", "hot"), interpolation="nearest")
    elif plot_type == "pie":
        ax.pie(values.get("sizes", []), labels=values.get("labels", []), autopct="%1.1f%%")
    elif plot_type == "radar":
        labels = values.get("labels", [])
        values_data = np.array(values.get("values", []))
        angles = np.linspace(0, 2*np.pi, len(labels), endpoint=False).tolist()
        values_data = np.concatenate((values_data, [values_data[0]]))
        angles += [angles[0]]
        ax.plot(angles, values_data, "o-", linewidth=2)
        ax.fill(angles, values_data, alpha=0.25)
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels)
    elif plot_type == "area":
        x = values.get("x", [])
        y = values.get("y", [])
        ax.fill_between(x, y, color=values.get("color", "skyblue"), alpha=0.4)
    elif plot_type == "bubblechart":
        x = values.get("x", [])
        y = values.get("y", [])
        size = values.get("size", [])
        ax.scatter(x, y, s=size, alpha=0.5)
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    img_str = base64.b64encode(buf.getvalue()).decode("utf-8")
    buf.close()
 
    return img_str
 
## Gridded data
def imshow_plot(X_values, Y_values):
    X, Y = np.meshgrid(np.linspace(*X_values), np.linspace(*Y_values))
    Z = (1 - X/2 + X**5 + Y**3) * np.exp(-X**2 - Y**2)
 
    fig, ax = plt.subplots()
    ax.imshow(Z, origin="lower")
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")
 
def pcolormesh_plot(x_values, Y_values):
    x = x_values
    X, Y = np.meshgrid(x, np.linspace(*Y_values))
    Z = (1 - X/2 + X**5 + Y**3) * np.exp(-X**2 - Y**2)
 
    fig, ax = plt.subplots()
    ax.pcolormesh(X, Y, Z, vmin=-0.5, vmax=1.0)
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")
 
def contour_plot(X_values, Y_values, levels):
    X, Y = np.meshgrid(np.linspace(*X_values), np.linspace(*Y_values))
    Z = (1 - X/2 + X**5 + Y**3) * np.exp(-X**2 - Y**2)
 
    fig, ax = plt.subplots()
    ax.contour(X, Y, Z, levels=np.linspace(np.min(Z), np.max(Z), levels))
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")
 
def contourf_plot(X_values, Y_values, levels):
    X, Y = np.meshgrid(np.linspace(-3, 3, 256), np.linspace(-3, 3, 256))
    Z = (1 - X/2 + X**5 + Y**3) * np.exp(-X**2 - Y**2)
    levels = np.linspace(Z.min(), Z.max(), 7)

    fig, ax = plt.subplots()
    ax.contourf(X, Y, Z, levels=levels)

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def barbs_plot(X_values, Y_values, levels):
    X, Y = np.meshgrid(X_values, Y_values)
    
    angle = np.pi / 180 * np.array(levels)  # Levels represent angles
    amplitude = np.random.randint(5, 100, size=angle.shape)  # Random amplitude for demonstration
    
    U = amplitude * np.sin(angle)
    V = amplitude * np.cos(angle)

    fig, ax = plt.subplots()
    ax.barbs(X, Y, U, V, barbcolor='C0', flagcolor='C0', length=7, linewidth=1.5)
    ax.set(xlim=(min(X_values)-0.5, max(X_values)+0.5), ylim=(min(Y_values)-0.5, max(Y_values)+0.5))

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)

    return base64.b64encode(buf.getvalue()).decode("utf-8")

def quiver_plot(X_values, Y_values, levels):
    x = np.linspace(-4, 4, 6)
    y = np.linspace(-4, 4, 6)
    X, Y = np.meshgrid(x, y)
    U = X + Y
    V = Y - X
    
    fig, ax = plt.subplots()
    ax.quiver(X, Y, U, V, color="C0", angles='xy', scale_units='xy', scale=5, width=.015)
    ax.set(xlim=(-5, 5), ylim=(-5, 5))

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def streamplot_plot(X_values, Y_values, levels):
    X, Y = np.meshgrid(np.linspace(-3, 3, 256), np.linspace(-3, 3, 256))
    Z = (1 - X/2 + X**5 + Y**3) * np.exp(-X**2 - Y**2)
    # make U and V out of the streamfunction:
    V = np.diff(Z[1:, :], axis=1)
    U = -np.diff(Z[:, 1:], axis=0)
    
    fig, ax = plt.subplots()
    ax.streamplot(X[1:, 1:], Y[1:, 1:], U, V)
    
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")

## Irregularly gridded data 
def tricontour_plot(x_values, y_values, seed=1):
    np.random.seed(seed)
    x = np.random.uniform(*x_values, 256)
    y = np.random.uniform(*y_values, 256)
    z = (1 - x / 2 + x**5 + y**3) * np.exp(-x**2 - y**2)
    levels = np.linspace(z.min(), z.max(), 7)
 
    fig, ax = plt.subplots()
    ax.plot(x, y, 'o', markersize=2, color="lightgrey")
    ax.tricontour(x, y, z, levels=levels)
    ax.set(xlim=x_values, ylim=y_values)
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")
 
def tricontourf_plot(x_values, y_values, seed=1):
    np.random.seed(seed)
    x = np.random.uniform(*x_values, 256)
    y = np.random.uniform(*y_values, 256)
    z = (1 - x / 2 + x**5 + y**3) * np.exp(-x**2 - y**2)
    levels = np.linspace(z.min(), z.max(), 7)
 
    fig, ax = plt.subplots()
    ax.plot(x, y, 'o', markersize=2, color="grey")
    ax.tricontourf(x, y, z, levels=levels)
    ax.set(xlim=x_values, ylim=y_values)
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")
 
def tripcolor_plot(x_values, y_values, seed=1):
    np.random.seed(seed)
    x = np.random.uniform(*x_values, 256)
    y = np.random.uniform(*y_values, 256)
    z = (1 - x / 2 + x**5 + y**3) * np.exp(-x**2 - y**2)
 
    fig, ax = plt.subplots()
    ax.plot(x, y, 'o', markersize=2, color="grey")
    ax.tripcolor(x, y, z)
    ax.set(xlim=x_values, ylim=y_values)
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")
 
def triplot_plot(x_values, y_values, seed=1):
    np.random.seed(seed)
    x = np.random.uniform(*x_values, 256)
    y = np.random.uniform(*y_values, 256)
 
    fig, ax = plt.subplots()
    ax.triplot(x, y)
    ax.set(xlim=x_values, ylim=y_values)
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    
    return base64.b64encode(buf.getvalue()).decode("utf-8")

## 3D and volumetric data 
def bar3d_plot(x, y, z, dx, dy, dz):
    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.bar3d(x, y, z, dx, dy, dz)
 
    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def fillbetween_plot(n):
    theta = np.linspace(0, 2*np.pi, n)
    x1 = np.cos(theta)
    y1 = np.sin(theta)
    z1 = np.linspace(0, 1, n)
    x2 = np.cos(theta + np.pi)
    y2 = np.sin(theta + np.pi)
    z2 = z1
 
    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.fill_between(x1, y1, z1, x2, y2, z2, alpha=0.5)
    ax.plot(x1, y1, z1, linewidth=2, color="C0")
    ax.plot(x2, y2, z2, linewidth=2, color="C0")
 
    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])
 
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def plot_plot(n):
    xs = np.linspace(0, 1, n)
    ys = np.sin(xs * 6 * np.pi)
    zs = np.cos(xs * 6 * np.pi)

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.plot(xs, ys, zs)

    ax.set(xticklabels=[],yticklabels=[],zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def quiverplot_plot(n):
    x = np.linspace(-1, 1, n)
    y = np.linspace(-1, 1, n)
    z = np.linspace(-1, 1, n)
    X, Y, Z = np.meshgrid(x, y, z)
    U = (X + Y)/5
    V = (Y - X)/5
    W = Z*0

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.quiver(X, Y, Z, U, V, W)

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def scatter_plot(n):
    rng = np.random.default_rng()
    xs = rng.uniform(23, 32, n)
    ys = rng.uniform(0, 100, n)
    zs = rng.uniform(-50, -25, n)

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.scatter(xs, ys, zs)

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def stem_plot(n):
    x = np.sin(np.linspace(0, 2*np.pi, n))
    y = np.cos(np.linspace(0, 2*np.pi, n))
    z = np.linspace(0, 1, n)

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.stem(x, y, z)

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def plotsurface_plot(n):
    X = np.arange(-5, 5, 0.25)
    Y = np.arange(-5, 5, 0.25)
    X, Y = np.meshgrid(X, Y)
    R = np.sqrt(X**2 + Y**2)
    Z = np.sin(R)

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.plot_surface(X, Y, Z, vmin=Z.min() * 2, cmap=cm.Blues)

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def plottrisurf_plot(n):
    radii = np.linspace(0.125, 1.0, n_radii)
    angles = np.linspace(0, 2*np.pi, n_angles, endpoint=False)[..., np.newaxis]

    x = np.append(0, (radii*np.cos(angles)).flatten())
    y = np.append(0, (radii*np.sin(angles)).flatten())
    z = np.sin(-x*y)

    fig, ax = plt.subplots(subplot_kw={'projection': '3d'})
    ax.plot_trisurf(x, y, z, vmin=z.min() * 2, cmap=cm.Blues)

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def voxels_plot(n):
    x, y, z = np.indices((8, 8, 8))

    cube1 = (x < 3) & (y < 3) & (z < 3)
    cube2 = (x >= 5) & (y >= 5) & (z >= 5)

    voxelarray = cube1 | cube2

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.voxels(voxelarray, edgecolor='k')

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def plotwireframe_plot(n):
    X, Y, Z = axes3d.get_test_data(0.05)

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.plot_wireframe(X, Y, Z, rstride=10, cstride=10)

    ax.set(xticklabels=[], yticklabels=[], zticklabels=[])

    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
 
    return base64.b64encode(buf.getvalue()).decode("utf-8")
