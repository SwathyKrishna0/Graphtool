from fastapi import APIRouter, HTTPException, UploadFile, File
from ..db.database import save_data, fetch_data
import pandas as pd
import os
 
router = APIRouter()
 
@router.post("/store-data")
async def store_data(data: dict, source: str):
    """Stores manual input data in Firebase."""
    try:
        save_data(source, data)
        return {"status": "success", "message": f"Manual data stored in {source}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error storing manual data: {str(e)}")
 
@router.post("/upload-csv")
async def upload_csv(file: UploadFile = File(...)):
    """Handles CSV uploads and stores extracted data in Firebase."""
    try:
        file_path = f"uploads/{file.filename}"
        with open(file_path, "wb") as f:
            f.write(file.file.read())
 
        df = pd.read_csv(file_path)
 
        if not {"x", "y"}.issubset(df.columns):
            raise HTTPException(status_code=400, detail="CSV must contain 'x' and 'y' columns.")
 
        graph_data = {"x": df["x"].tolist(), "y": df["y"].tolist()}
        save_data("CSV", graph_data)
 
        os.remove(file_path)  # Cleanup temp file
        return {"status": "success", "message": "CSV data stored in Firebase"}
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing CSV: {str(e)}")
 
@router.get("/get-data")
async def get_data():
    """Fetches stored graph data from Firebase."""
    data = fetch_data()
    
    if data:
        return {"data": data}
    else:
        return {"message": "No data available"}