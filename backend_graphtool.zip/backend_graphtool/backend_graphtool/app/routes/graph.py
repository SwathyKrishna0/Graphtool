from fastapi import APIRouter, Response, Query
from pydantic import BaseModel, Field
from ..services.predefined_graphs import ( generate_plot,
    imshow_plot, pcolormesh_plot, contour_plot,contourf_plot, barbs_plot,quiver_plot, streamplot_plot,  
    tricontour_plot, tricontourf_plot, tripcolor_plot, triplot_plot,
    bar3d_plot, fillbetween_plot, plot_plot, quiverplot_plot, scatter_plot, stem_plot, plotsurface_plot, plottrisurf_plot, voxels_plot, plotwireframe_plot
)
 
router = APIRouter()

class PlotRequest(BaseModel):
    plot_type: str
    values: dict

@router.post("/plot")
def get_plot(request: PlotRequest):
    img_str = generate_plot(request.plot_type, request.values)
    return {"plot": img_str}

# ✅ Gridded Data
class GriddedData(BaseModel):
    X_values: list
    Y_values: list
    levels: int = 7
 
@router.post("/plot/imshow")
async def get_imshow(data: GriddedData):
    plot_base64 = imshow_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
 
@router.post("/plot/pcolormesh")
async def get_pcolormesh(data: GriddedData):
    plot_base64 = pcolormesh_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
 
@router.post("/plot/contour")
async def get_contour(data: GriddedData):
    plot_base64 = contour_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/contourf")
async def get_contourf(data: GriddedData):
    plot_base64 = contourf_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/barbs")
async def get_barbs(data: GriddedData):
    plot_base64 = barbs_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
 
@router.post("/plot/quiver")
async def get_quiver(data: GriddedData):
    plot_base64 = quiver_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/streamplot")
async def get_streamplot(data: GriddedData):
    plot_base64 = streamplot_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

# ✅ Irregularly Gridded Data
class IrregularGridData(BaseModel):
    x_values: list
    y_values: list
    seed: int = 1
 
@router.post("/plot/tricontour")
async def get_tricontour(data: IrregularGridData):
    plot_base64 = tricontour_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
 
@router.post("/plot/tricontourf")
async def get_tricontourf(data: IrregularGridData):
    plot_base64 = tricontourf_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
 
@router.post("/plot/tripcolor")
async def get_tripcolor(data: IrregularGridData):
    plot_base64 = tripcolor_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

 
@router.post("/plot/triplot")
async def get_triplot(data: IrregularGridData):
    plot_base64 = triplot_plot(data.X_values, data.Y_values)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

 
# ✅ 3D & Volumetric Data
class Bar3DData(BaseModel):
    x:list
    y:list
    z:list
    dx:list
    dy:list
    dz:list

class FillBetweenData(BaseModel):
    n:int

class PlotData(BaseModel):
    n:int

class QuiverData(BaseModel):
    n:int

class ScatterData(BaseModel):
    xs:list
    ys:list
    zs:list

class StemData(BaseModel):
    x:list
    y:list
    z:list

class PlotsurfaceData(BaseModel):
    x:list
    y:list
    z:list

class PlottrisurfData(BaseModel):
    x:list
    y:list
    z:list

class VoxelsData(BaseModel):
    x:list
    y:list
    z:list

class PlotwireframeData(BaseModel):
    x:list
    y:list
    z:list

@router.post("/plot/bar3d")
async def get_bar3d(data:Bar3DData):
    plot_base64=bar3d_plot(data.x, data.y, data.z, data.dx, data.dy, data.dz)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/fillbetween")
async def get_fillbetween(data:FillBetweenData):
    plot_base64=fillbetween_plot(data.n)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/plot")
async def get_plot(data:PlotData):
    plot_base64=plot_plot(data.n)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
          
@router.post("/plot/quiverplot")
async def get_quiverplot(data:QuiverData):
    plot_base64=quiverplot_plot(data.n)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/scatter")
async def get_scatter(data:ScatterData):
    plot_base64=scatter_plot(data.xs,data.ys, data.zs)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/stem")
async def get_stem(data: StemData):
    plot_base64=stem_plot(data.x,data.y, data.z)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/plotsurface")
async def get_plotsurface(data: PlotsurfaceData):
    plot_base64=plotsurface_plot(data.x,data.y, data.z)
    return {"plot": f"data:image/png;base64,{plot_base64}"}
    
@router.post("/plot/plottrisurf")
async def get_plottrisurf(data: PlottrisurfData):
    plot_base64=plottrisurf_plot(data.x,data.y, data.z)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/voxels")
async def get_voxels(data:VoxelsData):
    plot_base64=voxels_plot(data.x,data.y, data.z)
    return {"plot": f"data:image/png;base64,{plot_base64}"}

@router.post("/plot/plotwireframe")
async def get_plotwireframe(data:PlotwireframeData):
    plot_base64=plotwireframe_plot(data.x,data.y, data.z)
    return {"plot": f"data:image/png;base64,{plot_base64}"}