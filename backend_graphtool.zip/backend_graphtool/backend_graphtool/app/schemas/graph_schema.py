from pydantic import BaseModel
from typing import List, Optional
 
class GraphRequest(BaseModel):
    """Validates incoming request for graph generation."""
    x: List[float]
    y: List[float]
    z:Optional[List[float]] =None
    graph_type: str