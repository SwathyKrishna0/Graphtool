from pydantic import BaseModel
 
class APIResponse(BaseModel):
    """Standard API response model."""
    status: str
    message: str