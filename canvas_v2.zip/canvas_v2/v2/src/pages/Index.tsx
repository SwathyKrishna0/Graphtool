
import Layout from '@/components/layout/Layout';
import ConfigPanel from '@/components/plot/ConfigPanel';
import GraphPreview from '@/components/plot/GraphPreview';
import JournalPresets from '@/components/plot/JournalPresets';
import PlotTypeSelector from '@/components/plot/PlotTypeSelector';
import CSVUpload from '@/components/plot/CSVUpload';
import SettingsDialog from '@/components/settings/SettingsDialog';
import DataColumnSelector from '@/components/plot/DataColumnSelector';
import UploadedDataTable from '@/components/plot/UploadedDataTable';
import DataDescription from '@/components/plot/DataDescription';
import { JOURNAL_PRESETS } from '@/lib/plotDefaults';
import { usePlotConfig } from '@/hooks/usePlotConfig';
import { toast } from '@/hooks/use-toast';

const Index = () => {
  const {
    config,
    data,
    uploadedData,
    selectedXColumn,
    selectedYColumn,
    updateConfig,
    applyJournalPreset,
    changePlotType,
    loadCSVData,
    setColumnSelection,
  } = usePlotConfig();

  const handleJournalPresetSelect = (presetId: string) => {
    const preset = JOURNAL_PRESETS.find((p) => p.id === presetId);
    if (preset) {
      applyJournalPreset(preset);
    }
  };

  const handleExport = () => {
    toast({
      title: "Export via Graph Preview",
      description: "Use the Export button in the graph preview panel for high-quality PNG export.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Layout config={config} updateConfig={updateConfig} onExport={handleExport}>
        <div className="mb-3">
          <h1 className="text-2xl font-bold text-science-800">Sci Plot Canvas</h1>
          <p className="text-gray-600 text-sm mt-1">
            Configure and generate interactive scientific plots with real-time editing and export capabilities.
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 h-[97vh] max-h-[97vh] overflow-hidden">
          {/* Left side - Settings and Configuration */}
          <div className="xl:col-span-3 space-y-3 overflow-y-auto max-h-full pr-2">
            <div className="bg-white shadow-sm rounded-lg p-3">
              <h3 className="text-sm font-medium mb-2 flex items-center gap-2">
                Settings & Configuration
              </h3>
              <SettingsDialog config={config} updateConfig={updateConfig} />
            </div>
            <div className="h-fit">
              <ConfigPanel config={config} updateConfig={updateConfig} />
            </div>
            <div className="h-fit">
              <JournalPresets onSelect={handleJournalPresetSelect} />
            </div>
          </div>

          {/* Center - Interactive Graph Preview */}
          <div className="xl:col-span-6 flex flex-col min-h-0 space-y-3">
            <div className="flex-1 min-h-0 bg-white rounded-lg shadow-sm p-2">
              <GraphPreview config={config} data={data} />
            </div>
            
            {/* Data Description Section */}
            <div className="h-fit">
              <DataDescription 
                data={uploadedData} 
                selectedXColumn={selectedXColumn}
                selectedYColumn={selectedYColumn}
              />
            </div>
          </div>

          {/* Right side - Plot Type, Data Upload & Management */}
          <div className="xl:col-span-3 space-y-3 overflow-y-auto max-h-full pr-2">
            <div className="h-fit">
              <PlotTypeSelector value={config.plotType} onChange={changePlotType} />
            </div>
            <div className="h-fit">
              <CSVUpload onDataLoad={loadCSVData} />
            </div>
            
            {/* Column Selection for Uploaded Data */}
            {uploadedData.length > 0 && (
              <div className="h-fit">
                <DataColumnSelector
                  data={data}
                  uploadedData={uploadedData}
                  selectedXColumn={selectedXColumn}
                  selectedYColumn={selectedYColumn}
                  onSelectionChange={setColumnSelection}
                />
              </div>
            )}
            
            {/* Uploaded Data Table */}
            <div className="h-fit">
              <UploadedDataTable data={uploadedData} />
            </div>
            
            {/* Manual Data Entry Table has been removed */}
          </div>
        </div>
      </Layout>
    </div>
  );
};

export default Index;
