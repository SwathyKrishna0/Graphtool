
import { PlotConfig, DataPoint } from '@/lib/plotDefaults';

export const createConfigHash = (config: PlotConfig, data: DataPoint[]) => {
  const validData = data.filter(point => point.x !== null && point.y !== null);
  return JSON.stringify({
    // All text configurations
    title: config.title,
    xLabel: config.xLabel,
    yLabel: config.yLabel,
    
    // Plot type and styling
    plotType: config.plotType,
    fontFamily: config.fontFamily,
    fontSize: config.fontSize,
    titleSize: config.titleSize,
    labelSize: config.labelSize,
    lineWidth: config.lineWidth,
    
    // Colors and visual settings
    colors: config.colors,
    backgroundColor: config.backgroundColor,
    
    // Display toggles
    showLegend: config.showLegend,
    showGrid: config.showGrid,
    
    // Data signature
    dataLength: validData.length,
    dataValues: validData.map(d => `${d.x}-${d.y}`).join('|')
  });
};
