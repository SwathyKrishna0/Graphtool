
import { PlotConfig, DataPoint } from '@/lib/plotDefaults';

// Use Vite's environment variable system - defaults to localhost:8000
const API_BASE_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';

export interface PlotResponse {
  plot?: string;
  plot_base64?: string;
  success?: boolean;
  error?: string;
}

// Test backend connectivity
export async function testBackendConnection(): Promise<boolean> {
  try {
    console.log(`Testing backend connection to: ${API_BASE_URL}`);
    const response = await fetch(`${API_BASE_URL}/`, {
      method: 'GET',
      mode: 'cors',
      headers: {
        'Accept': 'application/json',
      }
    });
    console.log(`Backend test response status: ${response.status}`);
    return response.ok;
  } catch (error) {
    console.error('Backend connection test failed:', error);
    return false;
  }
}

export class PlotApiService {
  static async generatePlot(config: PlotConfig, data: DataPoint[]): Promise<PlotResponse> {
    console.log('🚀 Starting plot generation...');
    console.log('Backend URL:', API_BASE_URL);
    console.log('Plot type:', config.plotType);
    
    // Test backend connection first
    const isConnected = await testBackendConnection();
    if (!isConnected) {
      return {
        success: false,
        error: `Cannot connect to backend at ${API_BASE_URL}. Please check:\n1. Backend is running\n2. CORS is enabled\n3. URL is correct`
      };
    }

    try {
      const validData = data.filter(point => point.x !== null && point.y !== null);
      
      if (validData.length === 0) {
        throw new Error('No valid data points provided');
      }

      // Create CSV content from data points
      const csvContent = [
        'x,y', // header
        ...validData.map(point => `${point.x},${point.y}`)
      ].join('\n');

      // Create a blob from CSV content
      const csvBlob = new Blob([csvContent], { type: 'text/csv' });
      const csvFile = new File([csvBlob], 'data.csv', { type: 'text/csv' });

      // Prepare config as JSON string
      const configJson = JSON.stringify({
        title: config.title,
        xlabel: config.xLabel,
        ylabel: config.yLabel,
        plot_type: config.plotType,
        font_family: config.fontFamily,
        font_size: config.fontSize,
        title_size: config.titleSize,
        label_size: config.labelSize,
        line_width: config.lineWidth,
        colors: config.colors,
        background_color: config.backgroundColor,
        show_legend: config.showLegend,
        show_grid: config.showGrid
      });

      // Create form data
      const formData = new FormData();
      formData.append('file', csvFile);
      formData.append('config', configJson);

      const url = `${API_BASE_URL}/api/plot/base64image`;

      console.log('📡 Sending request to:', url);
      console.log('📊 Config:', configJson);
      console.log('📈 Data points:', validData.length);

      const response = await fetch(url, {
        method: 'POST',
        mode: 'cors',
        body: formData
      });

      console.log('📨 Response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Backend error response:', errorText);
        throw new Error(`Backend returned ${response.status}: ${errorText}`);
      }

      // Parse JSON response instead of expecting direct base64 string
      const result = await response.json();
      console.log('✅ Backend JSON response received:', result);
      
      // Handle the JSON response format
      if (result && typeof result === 'object') {
        // Check if it's a direct base64 string response (wrapped in quotes)
        if (typeof result === 'string') {
          return { plot_base64: result };
        }
        // Check if it's an object with base64 data
        else if (result.plot_base64) {
          return { plot_base64: result.plot_base64 };
        }
        // Check if it's a simple string response (base64 data)
        else if (typeof result === 'string' && result.length > 100) {
          return { plot_base64: result };
        }
        // Handle any other format where the entire response might be the base64 string
        else {
          // If result is just a string value, treat it as base64
          const base64String = typeof result === 'string' ? result : JSON.stringify(result);
          if (base64String.length > 100) { // Basic check for base64 data
            return { plot_base64: base64String };
          }
        }
      }
      
      throw new Error('No valid plot data received from backend');
      
    } catch (error) {
      console.error('💥 Error generating plot:', error);
      
      if (error instanceof TypeError) {
        if (error.message.includes('fetch')) {
          return {
            success: false,
            error: `Network error: Cannot reach backend at ${API_BASE_URL}. Check if backend is running and CORS is enabled.`
          };
        }
      }
      
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }

  static async uploadCSV(file: File): Promise<any> {
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${API_BASE_URL}/api/plot/data-points`, {
        method: 'POST',
        mode: 'cors',
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Backend returned ${response.status}`);
      }

      const result = await response.json();
      console.log('CSV upload response:', result);
      
      return { success: true, data: result };
    } catch (error) {
      console.error('Error uploading CSV:', error);
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error(`Cannot connect to backend at ${API_BASE_URL}. Please ensure your backend is running.`);
      }
      
      throw error;
    }
  }

  // Legacy methods - keeping for compatibility but not actively used with new endpoints
  static async storeData(data: any, source: string): Promise<any> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/store-data?source=${source}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        throw new Error(`Backend returned ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error storing data:', error);
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error(`Cannot connect to backend at ${API_BASE_URL}. Please ensure your backend is running.`);
      }
      
      throw error;
    }
  }

  static async getData(): Promise<any> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/get-data`);

      if (!response.ok) {
        throw new Error(`Backend returned ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting data:', error);
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error(`Cannot connect to backend at ${API_BASE_URL}. Please ensure your backend is running.`);
      }
      
      throw error;
    }
  }
}
