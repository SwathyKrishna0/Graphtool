
import { Button } from '@/components/ui/button';
import { Download, RefreshCw } from 'lucide-react';

interface PlotControlsProps {
  isGenerating: boolean;
  hasValidData: boolean;
  autoRegenerate: boolean;
  plotImage: string | null;
  onGenerate: () => void;
  onExport: () => void;
}

const PlotControls = ({ 
  isGenerating, 
  hasValidData, 
  autoRegenerate, 
  plotImage, 
  onGenerate, 
  onExport 
}: PlotControlsProps) => {
  return (
    <div className="grid grid-cols-2 gap-2 mb-2">
      <Button 
        size="sm"
        className="bg-science-800 hover:bg-science-700 transition-colors shadow-md transform hover:translate-y-[-1px] hover:shadow-lg"
        onClick={onGenerate}
        disabled={isGenerating || !hasValidData}
      >
        {isGenerating ? (
          <>
            <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
            Applying Changes...
          </>
        ) : (
          <>
            <RefreshCw className="mr-2 h-3 w-3" />
            {autoRegenerate ? 'Regenerate Now' : 'Apply Changes'}
          </>
        )}
      </Button>
      
      <Button 
        size="sm"
        variant="outline"
        onClick={onExport}
        disabled={!plotImage}
        className="hover:bg-gray-50"
      >
        <Download className="mr-2 h-3 w-3" />
        Export PNG
      </Button>
    </div>
  );
};

export default PlotControls;
