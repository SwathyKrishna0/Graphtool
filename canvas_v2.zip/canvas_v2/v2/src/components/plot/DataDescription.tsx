
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, BarChart3 } from 'lucide-react';
import { useState, useEffect } from 'react';

interface DataDescriptionProps {
  data: any[];
  selectedXColumn?: string;
  selectedYColumn?: string;
}

const DataDescription = ({ data, selectedXColumn, selectedYColumn }: DataDescriptionProps) => {
  const [description, setDescription] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const generateDescription = async () => {
    if (!data || data.length === 0 || !selectedXColumn || !selectedYColumn) return;

    setIsLoading(true);
    try {
      // Extract the selected columns data
      const xValues = data.map(row => row[selectedXColumn]).filter(val => val !== null && val !== undefined);
      const yValues = data.map(row => row[selectedYColumn]).filter(val => val !== null && val !== undefined);

      // This would typically call your backend endpoint for data description
      // For now, I'll create a basic description
      const xStats = calculateStats(xValues);
      const yStats = calculateStats(yValues);

      const basicDescription = `
Dataset Analysis:
• Total data points: ${data.length}
• X-axis (${selectedXColumn}): Range ${xStats.min.toFixed(2)} to ${xStats.max.toFixed(2)}, Mean: ${xStats.mean.toFixed(2)}
• Y-axis (${selectedYColumn}): Range ${yStats.min.toFixed(2)} to ${yStats.max.toFixed(2)}, Mean: ${yStats.mean.toFixed(2)}
• Correlation: ${calculateCorrelation(xValues, yValues).toFixed(3)}
      `.trim();

      setDescription(basicDescription);
    } catch (error) {
      setDescription('Error generating data description. Please check your data and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const calculateStats = (values: number[]) => {
    const numericValues = values.map(v => Number(v)).filter(v => !isNaN(v));
    if (numericValues.length === 0) return { min: 0, max: 0, mean: 0 };
    
    return {
      min: Math.min(...numericValues),
      max: Math.max(...numericValues),
      mean: numericValues.reduce((a, b) => a + b, 0) / numericValues.length
    };
  };

  const calculateCorrelation = (x: any[], y: any[]) => {
    const xNums = x.map(v => Number(v)).filter(v => !isNaN(v));
    const yNums = y.map(v => Number(v)).filter(v => !isNaN(v));
    
    if (xNums.length !== yNums.length || xNums.length === 0) return 0;
    
    const n = xNums.length;
    const xMean = xNums.reduce((a, b) => a + b, 0) / n;
    const yMean = yNums.reduce((a, b) => a + b, 0) / n;
    
    let numerator = 0;
    let xVariance = 0;
    let yVariance = 0;
    
    for (let i = 0; i < n; i++) {
      const xDiff = xNums[i] - xMean;
      const yDiff = yNums[i] - yMean;
      numerator += xDiff * yDiff;
      xVariance += xDiff * xDiff;
      yVariance += yDiff * yDiff;
    }
    
    const denominator = Math.sqrt(xVariance * yVariance);
    return denominator === 0 ? 0 : numerator / denominator;
  };

  useEffect(() => {
    if (selectedXColumn && selectedYColumn && data.length > 0) {
      generateDescription();
    }
  }, [selectedXColumn, selectedYColumn, data]);

  return (
    <Card className="bg-white shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Data Description
        </CardTitle>
        <Button
          size="sm"
          variant="outline"
          onClick={generateDescription}
          disabled={isLoading || !selectedXColumn || !selectedYColumn}
        >
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-3 w-3" />
              Refresh
            </>
          )}
        </Button>
      </CardHeader>
      <CardContent>
        {!selectedXColumn || !selectedYColumn ? (
          <p className="text-gray-500 text-center py-4">
            Select X and Y columns to generate data description
          </p>
        ) : description ? (
          <div className="space-y-2">
            <pre className="text-sm bg-gray-50 p-3 rounded-md whitespace-pre-wrap font-mono">
              {description}
            </pre>
          </div>
        ) : (
          <p className="text-gray-500 text-center py-4">
            Click "Refresh" to generate data description
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default DataDescription;
