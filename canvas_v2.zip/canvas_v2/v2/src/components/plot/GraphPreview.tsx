
import { Card, CardContent } from '@/components/ui/card';
import { DataPoint, PlotConfig } from '@/lib/plotDefaults';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { usePlotGeneration } from '@/hooks/usePlotGeneration';
import PlotCanvas from './PlotCanvas';
import PlotControls from './PlotControls';
import AutoRegenerateToggle from './AutoRegenerateToggle';

interface GraphPreviewProps {
  config: PlotConfig;
  data: DataPoint[];
}

const GraphPreview = ({ config, data }: GraphPreviewProps) => {
  const {
    plotImage,
    isGenerating,
    hasValidData,
    backendStatus,
    autoRegenerate,
    setAutoRegenerate,
    handleGenerateGraph,
    handleExport
  } = usePlotGeneration(config, data);
  
  return (
    <Card className="flex flex-col h-full bg-gradient-to-br from-gray-50 to-white shadow-lg">
      <CardContent className="pt-4 flex-1 flex flex-col">
        {backendStatus === 'disconnected' && (
          <Alert variant="destructive" className="mb-3">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Backend connection failed. Make sure your FastAPI backend is running on port 8000 and CORS is properly configured.
            </AlertDescription>
          </Alert>
        )}
        
        <div className="flex-1 flex flex-col">
          <PlotCanvas 
            plotImage={plotImage}
            hasValidData={hasValidData}
            config={config}
            autoRegenerate={autoRegenerate}
          />
          
          <PlotControls
            isGenerating={isGenerating}
            hasValidData={hasValidData}
            autoRegenerate={autoRegenerate}
            plotImage={plotImage}
            onGenerate={() => handleGenerateGraph(false)}
            onExport={handleExport}
          />

          <AutoRegenerateToggle
            autoRegenerate={autoRegenerate}
            onToggle={setAutoRegenerate}
          />
          
          <p className="text-xs text-center text-gray-500">
            {!hasValidData 
              ? "Add data points to enable graph generation" 
              : plotImage 
                ? `${config.plotType} plot ${autoRegenerate ? '(live editing active)' : 'ready'}. Backend: ${backendStatus}`
                : `Ready to generate ${config.plotType}. Backend: ${backendStatus}`
            }
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default GraphPreview;
