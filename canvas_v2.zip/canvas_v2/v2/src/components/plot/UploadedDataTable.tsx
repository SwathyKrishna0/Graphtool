
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';

interface UploadedDataTableProps {
  data: any[];
}

const UploadedDataTable = ({ data }: UploadedDataTableProps) => {
  if (!data || data.length === 0) {
    return (
      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Uploaded Data</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center py-8">No data uploaded yet</p>
        </CardContent>
      </Card>
    );
  }

  const columns = Object.keys(data[0] || {});
  const maxRows = 100; // Limit display to first 100 rows for performance

  return (
    <Card className="bg-white shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg font-medium">
          Uploaded Data ({data.length} rows)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96 w-full rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                {columns.map((column) => (
                  <TableHead key={column}>{column}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.slice(0, maxRows).map((row, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{index + 1}</TableCell>
                  {columns.map((column) => (
                    <TableCell key={column}>
                      {row[column] !== null && row[column] !== undefined 
                        ? String(row[column]) 
                        : '-'}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
        {data.length > maxRows && (
          <p className="text-sm text-gray-500 mt-2">
            Showing first {maxRows} rows of {data.length} total rows
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default UploadedDataTable;
