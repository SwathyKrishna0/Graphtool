
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, FileText } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { PlotApiService } from '@/services/plotApiService';

interface CSVUploadProps {
  onDataLoad: (csvData: string) => void;
}

const CSVUpload = ({ onDataLoad }: CSVUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileRead = async (file: File) => {
    setIsUploading(true);
    
    try {
      // Try to upload to backend first
      const backendResult = await PlotApiService.uploadCSV(file);
      console.log('Backend upload result:', backendResult);
      
      toast({
        title: "CSV Uploaded to Backend",
        description: "Your data has been stored in the backend database.",
      });
    } catch (backendError) {
      console.warn('Backend upload failed, falling back to local processing:', backendError);
      
      toast({
        title: "Backend Upload Failed",
        description: "Processing CSV locally instead.",
        variant: "destructive",
      });
    }
    
    // Always process locally for frontend display
    const reader = new FileReader();
    reader.onload = (e) => {
      const csvData = e.target?.result as string;
      onDataLoad(csvData);
      
      toast({
        title: "CSV Loaded Locally",
        description: "Your data has been imported for preview.",
      });
      
      setIsUploading(false);
    };
    
    reader.onerror = () => {
      toast({
        title: "File Read Error",
        description: "Failed to read the CSV file.",
        variant: "destructive",
      });
      setIsUploading(false);
    };
    
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (isUploading) return;
    
    const files = Array.from(e.dataTransfer.files);
    const csvFile = files.find(file => file.type === 'text/csv' || file.name.endsWith('.csv'));
    
    if (csvFile) {
      handleFileRead(csvFile);
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a CSV file.",
        variant: "destructive",
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && !isUploading) {
      handleFileRead(file);
    }
  };

  return (
    <Card className="bg-white shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <FileText className="h-4 w-4" />
          Upload CSV Data
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div
          className={`border-2 border-dashed rounded-lg p-3 text-center transition-colors ${
            isDragging
              ? 'border-science-500 bg-science-50'
              : 'border-gray-300 hover:border-science-400'
          } ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}
          onDragOver={(e) => {
            e.preventDefault();
            if (!isUploading) setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
        >
          <Upload className="h-6 w-6 mx-auto mb-2 text-gray-400" />
          <p className="text-xs text-gray-600 mb-2">
            {isUploading ? 'Uploading CSV...' : 'Drag CSV or click to browse'}
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => !isUploading && fileInputRef.current?.click()}
            disabled={isUploading}
            className="text-xs px-3 py-1 h-7"
          >
            {isUploading ? 'Processing...' : 'Select File'}
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            onChange={handleFileSelect}
            className="hidden"
            disabled={isUploading}
          />
        </div>
        <p className="text-xs text-gray-500 mt-2 leading-tight">
          X values in first column, Y values in second column.
          {' '}File will be stored in backend database.
        </p>
      </CardContent>
    </Card>
  );
};

export default CSVUpload;
