
import { useEffect, useRef } from 'react';
import { PlotConfig } from '@/lib/plotDefaults';

interface PlotCanvasProps {
  plotImage: string | null;
  hasValidData: boolean;
  config: PlotConfig;
  autoRegenerate: boolean;
}

const PlotCanvas = ({ plotImage, hasValidData, config, autoRegenerate }: PlotCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const drawTextOverlays = (eraseBkg: boolean) => {
      if (eraseBkg) {
        ctx.fillStyle = config.backgroundColor || '#ffffff';
        // Erase title area
        ctx.fillRect(50, 5, canvas.width - 100, (config.titleSize || 16) * 1.5);
        // Erase X label area
        ctx.fillRect(50, canvas.height - (config.labelSize || 14) * 2, canvas.width - 100, (config.labelSize || 14) * 1.5);
        // Erase Y label area
        ctx.save();
        ctx.translate(20, canvas.height / 2);
        ctx.rotate(-Math.PI / 2);
        const yLabelWidth = ctx.measureText(config.yLabel || 'Y Axis').width;
        ctx.fillRect(-(yLabelWidth / 2) - 10, -15, yLabelWidth + 20, (config.labelSize || 14) * 1.5);
        ctx.restore();
      }

      // Add title using current config
      ctx.fillStyle = '#334155';
      ctx.font = `bold ${Math.min(config.titleSize || 16, 18)}px ${config.fontFamily || 'Arial'}`;
      ctx.textAlign = 'center';
      ctx.fillText(config.title || 'Scientific Plot', canvas.width / 2, 30);
      
      // Add axis labels using current config
      ctx.font = `${Math.min(config.labelSize || 14, 14)}px ${config.fontFamily || 'Arial'}`;
      ctx.fillText(config.xLabel || 'X Axis', canvas.width / 2, canvas.height - 15);
      
      // Y label (rotated)
      ctx.save();
      ctx.translate(20, canvas.height / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center';
      ctx.fillText(config.yLabel || 'Y Axis', 0, 0);
      ctx.restore();
    };
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (plotImage) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        drawTextOverlays(true);
      };
      img.src = plotImage;
    } else {
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, config.backgroundColor || '#f8fafc');
      gradient.addColorStop(1, '#f1f5f9');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      ctx.strokeRect(0, 0, canvas.width, canvas.height);
      
      if (!hasValidData) {
        ctx.fillStyle = '#666';
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Upload a CSV and select columns to generate a graph', canvas.width/2, canvas.height/2);
      } else {
        ctx.strokeStyle = config.colors[0] || '#94a3b8';
        ctx.lineWidth = 1;
        
        ctx.beginPath();
        ctx.moveTo(50, canvas.height - 50);
        ctx.lineTo(canvas.width - 50, canvas.height - 50);
        ctx.moveTo(50, canvas.height - 50);
        ctx.lineTo(50, 50);
        ctx.stroke();
        
        drawTextOverlays(false);
        
        ctx.fillStyle = '#64748b';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`${config.plotType} • ${config.fontFamily} • Grid: ${config.showGrid ? 'ON' : 'OFF'} • Legend: ${config.showLegend ? 'ON' : 'OFF'}`, canvas.width / 2, canvas.height - 35);
        
        if (autoRegenerate) {
          ctx.fillText('Auto-regenerate enabled - changes apply instantly', canvas.width / 2, canvas.height - 50);
        } else {
          ctx.fillText('Click "Apply Changes" to regenerate the plot', canvas.width / 2, canvas.height - 50);
        }
      }
    }
  }, [plotImage, hasValidData, config, autoRegenerate]);

  return (
    <div className="bg-white border rounded-lg flex-1 flex items-center justify-center mb-3 overflow-hidden shadow-inner transition-all hover:shadow-md">
      <canvas 
        ref={canvasRef} 
        width={600} 
        height={400} 
        className="max-w-full max-h-full"
      />
    </div>
  );
};

export default PlotCanvas;
