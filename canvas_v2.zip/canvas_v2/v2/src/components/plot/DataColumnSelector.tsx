
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { DataPoint } from '@/lib/plotDefaults';

interface DataColumnSelectorProps {
  data: DataPoint[];
  onSelectionChange: (xColumn: string, yColumn: string) => void;
  selectedXColumn?: string;
  selectedYColumn?: string;
  uploadedData: any[];
}

const DataColumnSelector = ({ 
  data, 
  onSelectionChange, 
  selectedXColumn, 
  selectedYColumn,
  uploadedData 
}: DataColumnSelectorProps) => {
  if (!uploadedData || uploadedData.length === 0) {
    return null;
  }

  // Get column names from the first row of uploaded data
  const columns = Object.keys(uploadedData[0] || {});
  
  const handleXColumnChange = (value: string) => {
    if (selectedYColumn) {
      onSelectionChange(value, selectedYColumn);
    }
  };

  const handleYColumnChange = (value: string) => {
    if (selectedXColumn) {
      onSelectionChange(selectedXColumn, value);
    }
  };

  return (
    <Card className="bg-white shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium">Data Column Selection</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="x-column">X-Axis Column</Label>
            <Select value={selectedXColumn} onValueChange={handleXColumnChange}>
              <SelectTrigger id="x-column">
                <SelectValue placeholder="Select X column" />
              </SelectTrigger>
              <SelectContent>
                {columns.map((column) => (
                  <SelectItem key={column} value={column}>
                    {column}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="y-column">Y-Axis Column</Label>
            <Select value={selectedYColumn} onValueChange={handleYColumnChange}>
              <SelectTrigger id="y-column">
                <SelectValue placeholder="Select Y column" />
              </SelectTrigger>
              <SelectContent>
                {columns.map((column) => (
                  <SelectItem key={column} value={column}>
                    {column}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DataColumnSelector;
