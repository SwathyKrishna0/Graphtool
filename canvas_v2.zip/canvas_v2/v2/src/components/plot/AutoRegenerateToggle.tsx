
import { Button } from '@/components/ui/button';
import { Eye, EyeOff } from 'lucide-react';

interface AutoRegenerateToggleProps {
  autoRegenerate: boolean;
  onToggle: (value: boolean) => void;
}

const AutoRegenerateToggle = ({ autoRegenerate, onToggle }: AutoRegenerateToggleProps) => {
  return (
    <div className="flex items-center justify-center gap-2 mb-2 p-2 bg-gray-50 rounded-lg">
      <Button
        size="sm"
        variant={autoRegenerate ? "default" : "outline"}
        onClick={() => onToggle(!autoRegenerate)}
        className="h-8 text-xs"
      >
        {autoRegenerate ? (
          <>
            <Eye className="mr-1 h-3 w-3" />
            Live Editing ON
          </>
        ) : (
          <>
            <EyeOff className="mr-1 h-3 w-3" />
            Manual Mode
          </>
        )}
      </Button>
      <span className="text-xs text-gray-600">
        {autoRegenerate ? 'Changes apply instantly' : 'Click to apply changes'}
      </span>
    </div>
  );
};

export default AutoRegenerateToggle;
