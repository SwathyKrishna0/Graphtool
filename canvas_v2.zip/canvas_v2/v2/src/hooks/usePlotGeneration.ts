
import { useState, useEffect } from 'react';
import { PlotConfig, DataPoint } from '@/lib/plotDefaults';
import { PlotApiService, testBackendConnection } from '@/services/plotApiService';
import { toast } from '@/hooks/use-toast';
import { createConfigHash } from '@/utils/configHash';

export const usePlotGeneration = (config: PlotConfig, data: DataPoint[]) => {
  const [plotImage, setPlotImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasValidData, setHasValidData] = useState(false);
  const [backendStatus, setBackendStatus] = useState<'unknown' | 'connected' | 'disconnected'>('unknown');
  const [autoRegenerate, setAutoRegenerate] = useState(true);
  const [lastConfigHash, setLastConfigHash] = useState<string>('');

  // Check if we have valid data
  useEffect(() => {
    const validData = data.filter(point => point.x !== null && point.y !== null);
    setHasValidData(validData.length >= 2);
  }, [data]);

  // Test backend connection on mount
  useEffect(() => {
    const checkBackend = async () => {
      const isConnected = await testBackendConnection();
      setBackendStatus(isConnected ? 'connected' : 'disconnected');
    };
    checkBackend();
  }, []);

  // Auto-regenerate plot when ANY config or data changes
  useEffect(() => {
    if (!hasValidData || backendStatus !== 'connected') return;
    
    const currentHash = createConfigHash(config, data);
    
    if (autoRegenerate) {
      // For auto-regenerate: always update if config changed
      if (currentHash !== lastConfigHash) {
        if (lastConfigHash !== '') {
          console.log('🔄 Configuration changed, auto-regenerating plot...');
          handleGenerateGraph(true); // Silent regeneration
        }
        setLastConfigHash(currentHash);
      }
    } else {
      // For manual mode: just update the hash
      setLastConfigHash(currentHash);
    }
  }, [config, data, hasValidData, autoRegenerate, backendStatus]);

  const handleGenerateGraph = async (silent = false) => {
    if (!hasValidData) {
      if (!silent) {
        toast({
          title: "Insufficient Data",
          description: "Please add at least two data points with valid values.",
          variant: "destructive",
        });
      }
      return;
    }
    
    setIsGenerating(true);
    
    try {
      console.log('🎯 Generating graph with current configuration...');
      console.log('📊 Config:', config);
      console.log('📈 Data points:', data.filter(point => point.x !== null && point.y !== null));
      
      const result = await PlotApiService.generatePlot(config, data);
      
      if (result.success === false || result.error) {
        throw new Error(result.error || 'Failed to generate plot');
      }
      
      if (result.plot_base64) {
        setPlotImage(`data:image/png;base64,${result.plot_base64}`);
        setBackendStatus('connected');
        
        // Update the config hash after successful generation
        setLastConfigHash(createConfigHash(config, data));
        
        if (!silent) {
          toast({
            title: "Graph Updated",
            description: `Your ${config.plotType} plot has been generated with current settings.`,
          });
        }
      } else {
        throw new Error('No plot data received from backend');
      }
    } catch (error) {
      console.error('❌ Error generating plot:', error);
      setBackendStatus('disconnected');
      if (!silent) {
        toast({
          title: "Generation Failed",
          description: error instanceof Error ? error.message : "Failed to generate plot. Please check your backend connection.",
          variant: "destructive",
        });
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExport = () => {
    if (!plotImage) {
      toast({
        title: "No Plot to Export",
        description: "Please generate a plot first.",
        variant: "destructive",
      });
      return;
    }
    
    const link = document.createElement('a');
    link.download = `${config.title.replace(/\s+/g, '-').toLowerCase()}-${config.plotType}-plot.png`;
    link.href = plotImage;
    link.click();
    
    toast({
      title: "Export Successful",
      description: "Your scientific plot has been downloaded.",
    });
  };

  return {
    plotImage,
    isGenerating,
    hasValidData,
    backendStatus,
    autoRegenerate,
    setAutoRegenerate,
    handleGenerateGraph,
    handleExport
  };
};
