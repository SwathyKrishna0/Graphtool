import { useState } from 'react';
import { DEFAULT_CONFIG, PlotConfig, DataPoint, JournalPreset } from '@/lib/plotDefaults';
import { PlotType } from '@/lib/plotTypes';
import { v4 as uuidv4 } from 'uuid';

export interface UsePlotConfigReturn {
  config: PlotConfig;
  data: DataPoint[];
  uploadedData: any[];
  selectedXColumn?: string;
  selectedYColumn?: string;
  updateConfig: (updates: Partial<PlotConfig>) => void;
  updateData: (newData: DataPoint[]) => void;
  applyJournalPreset: (preset: JournalPreset) => void;
  resetToDefault: () => void;
  changePlotType: (type: PlotType) => void;
  loadCSVData: (csvData: string) => void;
  setColumnSelection: (xColumn: string, yColumn: string) => void;
}

export function usePlotConfig(): UsePlotConfigReturn {
  const [config, setConfig] = useState<PlotConfig>(DEFAULT_CONFIG);
  const [data, setData] = useState<DataPoint[]>([]);
  const [uploadedData, setUploadedData] = useState<any[]>([]);
  const [selectedXColumn, setSelectedXColumn] = useState<string>();
  const [selectedYColumn, setSelectedYColumn] = useState<string>();

  const updateConfig = (updates: Partial<PlotConfig>) => {
    setConfig((prev) => ({ ...prev, ...updates }));
  };

  const updateData = (newData: DataPoint[]) => {
    setData(newData);
  };

  const applyJournalPreset = (preset: JournalPreset) => {
    setConfig((prev) => ({
      ...prev,
      fontFamily: preset.fontFamily,
      fontSize: preset.fontSize,
      titleSize: preset.titleSize,
      labelSize: preset.labelSize,
      lineWidth: preset.lineWidth,
      colors: [...preset.colors],
      backgroundColor: preset.backgroundColor,
    }));
  };

  const resetToDefault = () => {
    setConfig(DEFAULT_CONFIG);
  };

  const changePlotType = (type: PlotType) => {
    setConfig((prev) => ({ 
      ...prev, 
      plotType: type
    }));
  };

  const loadCSVData = (csvData: string) => {
    try {
      const lines = csvData.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim());
      
      // Parse all data for the uploaded data table
      const parsedUploadedData = lines.slice(1).map(line => {
        const values = line.split(',');
        const row: any = {};
        headers.forEach((header, index) => {
          const value = values[index]?.trim();
          const numValue = parseFloat(value);
          row[header] = isNaN(numValue) ? value : numValue;
        });
        return row;
      });
      
      setUploadedData(parsedUploadedData);
      
      // Auto-detect x and y columns for initial plot
      const xIndex = headers.findIndex(h => h.toLowerCase().includes('x') || h.toLowerCase().includes('time') || h.toLowerCase().includes('date'));
      const yIndex = headers.findIndex(h => h.toLowerCase().includes('y') || h.toLowerCase().includes('value') || h.toLowerCase().includes('data'));
      
      if (xIndex !== -1 && yIndex !== -1) {
        const xColumn = headers[xIndex];
        const yColumn = headers[yIndex];
        setSelectedXColumn(xColumn);
        setSelectedYColumn(yColumn);
        
        // Convert selected columns to DataPoint format
        const plotData = parsedUploadedData.map(row => ({
          id: uuidv4(),
          x: typeof row[xColumn] === 'number' ? row[xColumn] : parseFloat(row[xColumn]) || null,
          y: typeof row[yColumn] === 'number' ? row[yColumn] : parseFloat(row[yColumn]) || null,
        })).filter(point => point.x !== null && point.y !== null);
        
        setData(plotData);
      } else {
        // If no clear headers, use first two columns
        if (headers.length >= 2) {
          setSelectedXColumn(headers[0]);
          setSelectedYColumn(headers[1]);
          
          const plotData = parsedUploadedData.map(row => ({
            id: uuidv4(),
            x: typeof row[headers[0]] === 'number' ? row[headers[0]] : parseFloat(row[headers[0]]) || null,
            y: typeof row[headers[1]] === 'number' ? row[headers[1]] : parseFloat(row[headers[1]]) || null,
          })).filter(point => point.x !== null && point.y !== null);
          
          setData(plotData);
        }
      }
    } catch (error) {
      console.error('Error parsing CSV data:', error);
    }
  };

  const setColumnSelection = (xColumn: string, yColumn: string) => {
    setSelectedXColumn(xColumn);
    setSelectedYColumn(yColumn);
    
    if (uploadedData.length > 0) {
      const plotData = uploadedData.map(row => ({
        id: uuidv4(),
        x: typeof row[xColumn] === 'number' ? row[xColumn] : parseFloat(row[xColumn]) || null,
        y: typeof row[yColumn] === 'number' ? row[yColumn] : parseFloat(row[yColumn]) || null,
      })).filter(point => point.x !== null && point.y !== null);
      
      setData(plotData);
    }
  };

  return {
    config,
    data,
    uploadedData,
    selectedXColumn,
    selectedYColumn,
    updateConfig,
    updateData,
    applyJournalPreset,
    resetToDefault,
    changePlotType,
    loadCSVData,
    setColumnSelection,
  };
}
