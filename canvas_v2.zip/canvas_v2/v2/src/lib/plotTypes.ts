
export interface PlotTypeInfo {
  value: string;
  label: string;
  category: string;
  endpoint: string;
  dataStructure: 'basic' | 'gridded' | 'irregular' | 'scatter' | 'stem' | 'bar3d' | 'surface' | 'special';
}

export const PLOT_TYPES: PlotTypeInfo[] = [
  // Basic 2D Plots - use general /plot endpoint
  { value: 'line', label: 'Line Plot', category: 'Basic 2D', endpoint: '/plot', dataStructure: 'basic' },
  { value: 'bar', label: 'Bar Chart', category: 'Basic 2D', endpoint: '/plot', dataStructure: 'basic' },
  { value: 'histogram', label: 'Histogram', category: 'Basic 2D', endpoint: '/plot', dataStructure: 'basic' },
  
  // Gridded Data Plots - use specific endpoints with GriddedData
  { value: 'imshow', label: 'Image Show', category: 'Gridded Data', endpoint: '/plot/imshow', dataStructure: 'gridded' },
  { value: 'pcolormesh', label: 'Pcolormesh', category: 'Gridded Data', endpoint: '/plot/pcolormesh', dataStructure: 'gridded' },
  { value: 'contour', label: 'Contour Lines', category: 'Gridded Data', endpoint: '/plot/contour', dataStructure: 'gridded' },
  { value: 'contourf', label: 'Filled Contours', category: 'Gridded Data', endpoint: '/plot/contourf', dataStructure: 'gridded' },
  { value: 'quiver', label: 'Quiver Plot', category: 'Vector Fields', endpoint: '/plot/quiver', dataStructure: 'gridded' },
  { value: 'barbs', label: 'Wind Barbs', category: 'Vector Fields', endpoint: '/plot/barbs', dataStructure: 'gridded' },
  { value: 'streamplot', label: 'Stream Plot', category: 'Vector Fields', endpoint: '/plot/streamplot', dataStructure: 'gridded' },
  
  // Irregular Grid Plots - use specific endpoints with IrregularGridData  
  { value: 'tricontour', label: 'Triangular Contour', category: 'Irregular Grid', endpoint: '/plot/tricontour', dataStructure: 'irregular' },
  { value: 'tricontourf', label: 'Filled Tri Contour', category: 'Irregular Grid', endpoint: '/plot/tricontourf', dataStructure: 'irregular' },
  { value: 'tripcolor', label: 'Triangular Color', category: 'Irregular Grid', endpoint: '/plot/tripcolor', dataStructure: 'irregular' },
  { value: 'triplot', label: 'Triangle Plot', category: 'Irregular Grid', endpoint: '/plot/triplot', dataStructure: 'irregular' },
  
  // Scatter and Stem plots
  { value: 'scatter', label: 'Scatter Plot', category: 'Basic 2D', endpoint: '/plot/scatter', dataStructure: 'scatter' },
  { value: 'stem', label: 'Stem Plot', category: 'Basic 2D', endpoint: '/plot/stem', dataStructure: 'stem' },
  
  // 3D Plots
  { value: 'bar3d', label: '3D Bar Chart', category: '3D Plots', endpoint: '/plot/bar3d', dataStructure: 'bar3d' },
  { value: 'plotsurface', label: '3D Surface', category: '3D Plots', endpoint: '/plot/plotsurface', dataStructure: 'surface' },
  { value: 'plottrisurf', label: '3D Triangular Surface', category: '3D Plots', endpoint: '/plot/plottrisurf', dataStructure: 'surface' },
  { value: 'plotwireframe', label: '3D Wireframe', category: '3D Plots', endpoint: '/plot/plotwireframe', dataStructure: 'surface' },
  { value: 'voxels', label: '3D Voxels', category: '3D Plots', endpoint: '/plot/voxels', dataStructure: 'surface' },
  
  // Special Plots
  { value: 'fillbetween', label: 'Fill Between', category: 'Special', endpoint: '/plot/fillbetween', dataStructure: 'special' },
  { value: 'plot', label: 'Generic Plot', category: 'Special', endpoint: '/plot/plot', dataStructure: 'special' },
  { value: 'quiverplot', label: 'Quiver Plot 2D', category: 'Special', endpoint: '/plot/quiverplot', dataStructure: 'special' },
];

export type PlotType = typeof PLOT_TYPES[number]['value'];
