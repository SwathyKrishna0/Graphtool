import { PlotType } from './plotTypes';

export type DataPoint = {
  id: string;
  x: number | null;
  y: number | null;
};

export type JournalPreset = {
  id: string;
  name: string;
  fontFamily: string;
  fontSize: number;
  titleSize: number;
  labelSize: number;
  lineWidth: number;
  colors: string[];
  backgroundColor: string;
};

export type PlotConfig = {
  title: string;
  xLabel: string;
  yLabel: string;
  plotType: PlotType;
  fontFamily: string;
  fontSize: number;
  titleSize: number;
  labelSize: number;
  lineWidth: number;
  colors: string[];
  backgroundColor: string;
  showLegend: boolean;
  showGrid: boolean;
};

export const JOURNAL_PRESETS: JournalPreset[] = [
  {
    id: 'default',
    name: 'Default',
    fontFamily: 'Arial',
    fontSize: 12,
    titleSize: 16,
    labelSize: 14,
    lineWidth: 2,
    colors: ['#4338ca', '#38b2ac', '#f56565', '#9f7aea', '#38a169'],
    backgroundColor: '#ffffff',
  },
  {
    id: 'nature',
    name: 'Nature',
    fontFamily: 'Arial',
    fontSize: 8,
    titleSize: 12,
    labelSize: 10,
    lineWidth: 1,
    colors: ['#000000', '#E64B35', '#4DBBD5', '#00A087', '#3C5488'],
    backgroundColor: '#ffffff',
  },
  {
    id: 'science',
    name: 'Science',
    fontFamily: 'Arial',
    fontSize: 9,
    titleSize: 14,
    labelSize: 12,
    lineWidth: 1.5,
    colors: ['#3B4992', '#EE0000', '#008B45', '#631879', '#008280'],
    backgroundColor: '#ffffff',
  },
  {
    id: 'ieee',
    name: 'IEEE',
    fontFamily: 'Times New Roman',
    fontSize: 8,
    titleSize: 11,
    labelSize: 9,
    lineWidth: 1,
    colors: ['#0072B2', '#E69F00', '#56B4E9', '#009E73', '#F0E442'],
    backgroundColor: '#ffffff',
  }
];

export const DEFAULT_CONFIG: PlotConfig = {
  title: 'My Scientific Plot',
  xLabel: 'X Axis',
  yLabel: 'Y Axis',
  plotType: 'line',
  fontFamily: 'Arial',
  fontSize: 12,
  titleSize: 16,
  labelSize: 14,
  lineWidth: 2,
  colors: ['#4338ca', '#38b2ac', '#f56565', '#9f7aea', '#38a169'],
  backgroundColor: '#ffffff',
  showLegend: true,
  showGrid: true,
};

// Enhanced color palettes for graph customization
export const COLOR_PALETTES = [
  {
    id: 'scientific',
    name: 'Scientific',
    colors: ['#4338ca', '#38b2ac', '#f56565', '#9f7aea', '#38a169'],
  },
  {
    id: 'pastel',
    name: 'Pastel',
    colors: ['#F2FCE2', '#FEF7CD', '#FEC6A1', '#E5DEFF', '#FFDEE2'],
  },
  {
    id: 'vibrant',
    name: 'Vibrant',
    colors: ['#8B5CF6', '#D946EF', '#F97316', '#0EA5E9', '#22C55E'],
  },
  {
    id: 'monochrome',
    name: 'Monochrome',
    colors: ['#333333', '#555555', '#777777', '#999999', '#BBBBBB'],
  },
  {
    id: 'gradient',
    name: 'Gradient',
    colors: ['#1a365d', '#2a4a73', '#3c5d8f', '#7596c5', '#9fb4d9'],
  },
];

export const FONT_FAMILIES = [
  'Arial',
  'Times New Roman',
  'Helvetica',
  'Courier New',
  'Georgia',
  'Palatino',
  'Garamond',
  'Comic Sans MS',
  'Trebuchet MS',
  'Verdana',
  'Impact',
];
